import React, { useContext } from 'react';
import { HashRouter as Router, Routes, Route, NavLink, Link } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { AppProvider, AppContext } from './context/AppContext';
import Home from './pages/Home';
import Explore from './pages/Explore';
import Profile from './pages/Profile';
import Requests from './pages/Requests';
import Dashboard from './pages/Dashboard';
import Chat from './pages/Chat';
import Auth from './pages/Auth';

import { 
  Home as HomeIcon, 
  Compass, 
  GitPullRequest, 
  BarChart3, 
  MessageSquare, 
  User, 
  Award,
  Zap,
  LogOut
} from 'lucide-react';

const Layout = ({ children }) => {
  const { currentUser, requests, logoutUser } = useContext(AppContext);
  
  if (!currentUser) return null;

  // Calculate pending incoming requests count for badge
  const pendingCount = requests.filter(
    req => req.receiverId === currentUser.id && req.status === 'pending'
  ).length;

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <Link to="/" style={{ textDecoration: 'none' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '35px', paddingLeft: '8px' }}>
            <div style={{
              background: 'var(--gradient-primary)',
              width: '38px',
              height: '38px',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 10px rgba(99, 102, 241, 0.4)'
            }}>
              <Zap size={20} color="#fff" />
            </div>
            <div>
              <h2 className="logo-text" style={{ 
                fontSize: '1.4rem', 
                fontWeight: '800', 
                letterSpacing: '-0.5px',
                background: 'linear-gradient(to right, #ffffff, #9ca3af)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>
                SkillSwap
              </h2>
              <span className="logo-text text-gradient" style={{ fontSize: '0.7rem', fontWeight: '700', letterSpacing: '1px', textTransform: 'uppercase' }}>
                Exchange Hub
              </span>
            </div>
          </div>
        </Link>

        {/* Navigation Items */}
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px', flex: 1 }}>
          <NavLink 
            to="/" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={navStyle}
          >
            <HomeIcon size={18} />
            <span className="nav-text">Home</span>
          </NavLink>

          <NavLink 
            to="/explore" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={navStyle}
          >
            <Compass size={18} />
            <span className="nav-text">Explore Skills</span>
          </NavLink>

          <NavLink 
            to="/requests" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={{ ...navStyle, position: 'relative' }}
          >
            <GitPullRequest size={18} />
            <span className="nav-text">Requests</span>
            {pendingCount > 0 && (
              <span className="badge-notification">{pendingCount}</span>
            )}
          </NavLink>

          <NavLink 
            to="/dashboard" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={navStyle}
          >
            <BarChart3 size={18} />
            <span className="nav-text">Dashboard</span>
          </NavLink>

          <NavLink 
            to="/chat" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={navStyle}
          >
            <MessageSquare size={18} />
            <span className="nav-text">Chat Arena</span>
          </NavLink>

          <NavLink 
            to="/profile" 
            className={({ isActive }) => `btn btn-secondary ${isActive ? 'active-nav' : ''}`}
            style={navStyle}
          >
            <User size={18} />
            <span className="nav-text">My Profile</span>
          </NavLink>
        </nav>

        {/* User Mini Profile Panel */}
        <div className="profile-details glass-panel" style={{
          padding: '12px',
          borderRadius: '14px',
          display: 'flex',
          flexDirection: 'column',
          gap: '10px',
          background: 'rgba(255, 255, 255, 0.02)',
          marginTop: 'auto'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', width: '100%' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              background: 'var(--gradient-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '0.85rem',
              fontWeight: '700',
              color: '#fff',
              border: '1px solid rgba(255, 255, 255, 0.15)',
              boxShadow: '0 4px 10px rgba(99, 102, 241, 0.2)'
            }}>
              {currentUser.name ? currentUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <h4 style={{ fontSize: '0.85rem', fontWeight: '600', color: '#f3f4f6', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {currentUser.name}
              </h4>
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px', marginTop: '2px' }}>
                <Award size={12} className="text-gradient" />
                <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', fontWeight: '600' }}>
                  Lvl {currentUser.level}
                </span>
              </div>
            </div>
          </div>
          
          {/* Level progress bar */}
          <div style={{
            width: '100%',
            height: '4px',
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            borderRadius: '2px',
            overflow: 'hidden'
          }}>
            <div style={{
              height: '100%',
              width: `${(currentUser.xp / currentUser.xpToNextLevel) * 100}%`,
              background: 'var(--gradient-primary)',
              borderRadius: '2px'
            }}></div>
          </div>

          {/* Logout Button */}
          <button 
            onClick={logoutUser}
            className="btn btn-secondary"
            style={{ 
              width: '100%', 
              padding: '6px 12px', 
              fontSize: '0.8rem', 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              gap: '6px',
              marginTop: '4px',
              borderColor: 'rgba(239, 68, 68, 0.2)',
              color: 'var(--color-danger)'
            }}
          >
            <LogOut size={14} /> Log Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        {children}
      </main>
    </div>
  );
};

const navStyle = {
  display: 'flex',
  justifyContent: 'flex-start',
  alignItems: 'center',
  padding: '12px 16px',
  borderRadius: '12px',
  gap: '12px',
  color: 'var(--text-secondary)',
  background: 'transparent',
  border: 'none',
  textAlign: 'left',
  width: '100%',
  textDecoration: 'none'
};

const navStylesInline = `
  .active-nav {
    background: rgba(99, 102, 241, 0.1) !important;
    color: var(--text-primary) !important;
    border-left: 3px solid var(--color-primary) !important;
    border-radius: 0 12px 12px 0 !important;
    padding-left: 13px !important;
  }
  
  .badge-notification {
    position: absolute;
    right: 16px;
    background: var(--color-danger);
    color: #fff;
    font-size: 0.7rem;
    font-weight: 700;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    display: flex;
    alignItems: center;
    justifyContent: center;
    box-shadow: 0 2px 8px rgba(239, 68, 68, 0.4);
  }
`;

const AppContent = () => {
  const { currentUser } = useContext(AppContext);

  if (!currentUser) {
    return <Auth />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/requests" element={<Requests />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/profile" element={<Profile />} />
      </Routes>
    </Layout>
  );
};

function App() {
  return (
    <Router>
      <style>{navStylesInline}</style>
      <AppProvider>
        <AppContent />
        <ToastContainer position="top-right" autoClose={3000} theme="dark" />
      </AppProvider>
    </Router>
  );
}

export default App;
