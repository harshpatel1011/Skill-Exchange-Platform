import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  User, 
  Award, 
  Plus, 
  X, 
  Edit3, 
  Check, 
  Zap, 
  Star,
  CheckSquare
} from 'lucide-react';

const Profile = () => {
  const { currentUser, updateProfile } = useContext(AppContext);
  const [isEditing, setIsEditing] = useState(false);
  
  // Form fields state
  const [name, setName] = useState(currentUser.name);
  const [title, setTitle] = useState(currentUser.title);
  const [bio, setBio] = useState(currentUser.bio);
  
  // Interactive Tag Editor State
  const [newTeachSkill, setNewTeachSkill] = useState('');
  const [newLearnSkill, setNewLearnSkill] = useState('');
  const [skillsTeach, setSkillsTeach] = useState(currentUser.skillsTeach);
  const [skillsLearn, setSkillsLearn] = useState(currentUser.skillsLearn);

  const handleProfileSave = (e) => {
    e.preventDefault();
    updateProfile({
      name,
      title,
      bio,
      skillsTeach,
      skillsLearn
    });
    setIsEditing(false);
  };

  const addTeachSkill = () => {
    if (newTeachSkill.trim() && !skillsTeach.includes(newTeachSkill.trim())) {
      setSkillsTeach([...skillsTeach, newTeachSkill.trim()]);
      setNewTeachSkill('');
    }
  };

  const removeTeachSkill = (skill) => {
    setSkillsTeach(skillsTeach.filter(s => s !== skill));
  };

  const addLearnSkill = () => {
    if (newLearnSkill.trim() && !skillsLearn.includes(newLearnSkill.trim())) {
      setSkillsLearn([...skillsLearn, newLearnSkill.trim()]);
      setNewLearnSkill('');
    }
  };

  const removeLearnSkill = (skill) => {
    setSkillsLearn(skillsLearn.filter(s => s !== skill));
  };

  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .profile-hero {
          padding: 40px;
          border-radius: 20px;
          display: flex;
          gap: 30px;
          align-items: center;
          margin-bottom: 40px;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.08) 0%, rgba(236, 72, 153, 0.04) 100%);
        }
        @media (max-width: 768px) {
          .profile-hero {
            flex-direction: column;
            text-align: center;
            padding: 24px;
          }
        }
        .achievement-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 20px;
        }
        .badge-card {
          padding: 20px;
          border-radius: 16px;
          display: flex;
          gap: 16px;
          align-items: center;
          background: rgba(255, 255, 255, 0.02);
          transition: var(--transition-smooth);
        }
        .badge-card.locked {
          opacity: 0.45;
          filter: grayscale(1);
        }
        .badge-card.locked:hover {
          filter: none;
          opacity: 0.8;
          border-color: rgba(255, 255, 255, 0.1);
        }
        .badge-circle {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justifyContent: center;
          font-size: 1.5rem;
          background: rgba(255, 255, 255, 0.06);
          box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .badge-card.unlocked .badge-circle {
          background: var(--gradient-primary);
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
        }
        .interactive-tag {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 8px;
          font-size: 0.85rem;
          font-weight: 500;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: var(--text-primary);
          transition: var(--transition-smooth);
        }
        .tag-remove-btn {
          background: transparent;
          border: none;
          color: var(--text-muted);
          cursor: pointer;
          display: flex;
          align-items: center;
          justifyContent: center;
          padding: 1px;
          border-radius: 50%;
        }
        .tag-remove-btn:hover {
          background: rgba(239, 68, 68, 0.2);
          color: var(--color-danger);
        }
      `}</style>

      {/* Main Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '35px' }}>
        <div>
          <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#fff' }}>My Platform Profile</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage your personal details, tags, achievements, and statistics.</p>
        </div>
        {!isEditing && (
          <button className="btn btn-secondary" onClick={() => setIsEditing(true)}>
            <Edit3 size={16} /> Edit Profile
          </button>
        )}
      </div>

      {/* Profile Info block */}
      {!isEditing ? (
        // VIEW MODE PROFILE HEADER
        <section className="glass-panel profile-hero">
          <div style={{
            width: '110px',
            height: '110px',
            borderRadius: '22px',
            background: 'var(--gradient-primary)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '2rem',
            fontWeight: '800',
            color: '#fff',
            border: '2px solid rgba(255, 255, 255, 0.15)',
            boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
            flexShrink: 0
          }}>
            {currentUser.name ? currentUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'center', marginBottom: '6px' }}>
              <h2 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#fff' }}>{currentUser.name}</h2>
              <span className="badge badge-tech" style={{ padding: '6px 12px', fontSize: '0.75rem' }}>
                Level {currentUser.level} Contributor
              </span>
            </div>
            <p style={{ fontSize: '1rem', color: 'var(--color-secondary)', fontWeight: '600', marginBottom: '12px' }}>{currentUser.title}</p>
            <p style={{ fontSize: '0.925rem', color: 'var(--text-secondary)', lineHeight: '1.6', maxWidth: '800px' }}>
              "{currentUser.bio}"
            </p>

            {/* Quick Metrics */}
            <div style={{ display: 'flex', gap: '28px', flexWrap: 'wrap', marginTop: '24px', borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '18px' }}>
              <div>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Member Rating</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
                  <Star size={16} fill="#fbbf24" stroke="#fbbf24" />
                  <span style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>{currentUser.rating}</span>
                  <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>({currentUser.reviewsCount} reviews)</span>
                </div>
              </div>
              
              <div>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Completed Contracts</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '4px' }}>
                  <CheckSquare size={16} className="text-gradient" />
                  <span style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>{currentUser.completedExchanges} Exchanges</span>
                </div>
              </div>

              <div>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Experience points (XP)</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '4px' }}>
                  <Zap size={16} style={{ color: 'var(--color-warning)' }} />
                  <span style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>{currentUser.xp} / {currentUser.xpToNextLevel} XP</span>
                </div>
              </div>
            </div>

          </div>
        </section>
      ) : (
        // EDIT MODE PROFILE HEADER
        <form onSubmit={handleProfileSave} className="glass-panel" style={{ padding: '30px', marginBottom: '40px', background: 'rgba(99, 102, 241, 0.03)' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: '700', color: '#fff', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '10px' }}>
            Edit Personal Profile Details
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Full Name:</label>
              <input 
                type="text" 
                className="form-input" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                required 
              />
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">Professional Subtitle:</label>
              <input 
                type="text" 
                className="form-input" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)} 
                required 
              />
            </div>
          </div>

          <div className="form-group" style={{ marginBottom: '24px' }}>
            <label className="form-label">Personal Bio / Pitch Summary:</label>
            <textarea 
              className="form-input" 
              style={{ minHeight: '80px', resize: 'vertical' }}
              value={bio} 
              onChange={(e) => setBio(e.target.value)} 
              required
            ></textarea>
          </div>

          {/* EDIT TAGS SECTION */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '30px' }}>
            
            {/* Skills I Can Teach Editor */}
            <div>
              <label className="form-label">Skills I Can Teach:</label>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="e.g. React, Docker, Cooking" 
                  value={newTeachSkill}
                  onChange={(e) => setNewTeachSkill(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTeachSkill())}
                />
                <button type="button" className="btn btn-secondary" onClick={addTeachSkill} style={{ padding: '0 16px' }}>
                  <Plus size={18} />
                </button>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {skillsTeach.map(skill => (
                  <span key={skill} className="interactive-tag">
                    {skill}
                    <button type="button" className="tag-remove-btn" onClick={() => removeTeachSkill(skill)}>
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            {/* Skills I Want to Learn Editor */}
            <div>
              <label className="form-label">Skills I Want to Learn:</label>
              <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="e.g. Guitar, French, Baking" 
                  value={newLearnSkill}
                  onChange={(e) => setNewLearnSkill(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addLearnSkill())}
                />
                <button type="button" className="btn btn-secondary" onClick={addLearnSkill} style={{ padding: '0 16px' }}>
                  <Plus size={18} />
                </button>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                {skillsLearn.map(skill => (
                  <span key={skill} className="interactive-tag" style={{ borderColors: 'rgba(236,72,153,0.2)' }}>
                    {skill}
                    <button type="button" className="tag-remove-btn" onClick={() => removeLearnSkill(skill)}>
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            </div>

          </div>

          <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-secondary" onClick={() => {
              setName(currentUser.name);
              setTitle(currentUser.title);
              setBio(currentUser.bio);
              setSkillsTeach(currentUser.skillsTeach);
              setSkillsLearn(currentUser.skillsLearn);
              setIsEditing(false);
            }}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              <Check size={16} /> Save Profile Changes
            </button>
          </div>

        </form>
      )}

      {/* Skills Display Cards in view mode */}
      {!isEditing && (
        <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '28px', marginBottom: '40px' }}>
          
          <div className="glass-panel" style={{ padding: '28px' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--color-primary)' }}></span>
              Skills I Teach
            </h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              {currentUser.skillsTeach.map(skill => (
                <span key={skill} className="badge badge-tech" style={{ padding: '8px 14px', fontSize: '0.85rem', textTransform: 'none' }}>
                  {skill}
                </span>
              ))}
            </div>
          </div>

          <div className="glass-panel" style={{ padding: '28px' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--color-accent)' }}></span>
              Skills I Learn
            </h3>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              {currentUser.skillsLearn.map(skill => (
                <span key={skill} className="badge badge-creative" style={{ padding: '8px 14px', fontSize: '0.85rem', textTransform: 'none' }}>
                  {skill}
                </span>
              ))}
            </div>
          </div>

        </section>
      )}

      {/* Gamified Achievements Block */}
      <section>
        <h2 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#fff', marginBottom: '8px' }}>Achievements & Badges</h2>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '24px' }}>Log hours and exchange skills to level up your contribution rank.</p>

        <div className="achievement-grid">
          {currentUser.achievements.map(ach => (
            <div 
              key={ach.id} 
              className={`glass-panel badge-card ${ach.unlocked ? 'unlocked' : 'locked'}`}
            >
              <div className="badge-circle">
                {ach.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h4 style={{ fontSize: '0.95rem', fontWeight: '700', color: '#fff' }}>{ach.name}</h4>
                  {ach.unlocked ? (
                    <span style={{ fontSize: '0.7rem', color: 'var(--color-success)', fontWeight: 'bold' }}>Unlocked</span>
                  ) : (
                    <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 'bold' }}>Locked</span>
                  )}
                </div>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '4px', lineHeight: '1.4' }}>
                  {ach.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};

export default Profile;
