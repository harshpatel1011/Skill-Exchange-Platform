import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  Check, 
  X, 
  Trash2, 
  Edit3, 
  Award, 
  Star,
  Clock,
  ArrowRight,
  TrendingUp,
  Inbox,
  Send,
  CheckCircle,
  FileCheck
} from 'lucide-react';

const Requests = () => {
  const { 
    requests, 
    users, 
    currentUser,
    updateRequestStatus, 
    cancelExchangeRequest, 
    editExchangeRequest,
    toggleMilestone,
    submitExchangeRating 
  } = useContext(AppContext);

  const [activeTab, setActiveTab] = useState('received'); // 'received', 'sent', 'active', 'completed'
  
  // Edit Request State
  const [editingRequest, setEditingRequest] = useState(null);
  const [editCommitment, setEditCommitment] = useState('');
  const [editMessage, setEditMessage] = useState('');

  // Rating Feedback State
  const [ratingRequest, setRatingRequest] = useState(null);
  const [ratingVal, setRatingVal] = useState(5);

  const getMemberDetails = (userId) => {
    return users.find(u => u.id === userId) || {
      name: 'External Member',
      title: 'Expert Peer'
    };
  };

  // Group Requests Dynamically based on current logged in user ID
  const receivedProposals = requests.filter(r => r.receiverId === currentUser.id && r.status === 'pending');
  const sentProposals = requests.filter(r => r.senderId === currentUser.id && r.status === 'pending');
  const activeContracts = requests.filter(r => r.status === 'approved' && (r.senderId === currentUser.id || r.receiverId === currentUser.id));
  const completedContracts = requests.filter(r => r.status === 'completed' && (r.senderId === currentUser.id || r.receiverId === currentUser.id));

  const handleEditClick = (req) => {
    setEditingRequest(req);
    setEditCommitment(req.commitment);
    setEditMessage(req.message);
  };

  const handleEditSave = (e) => {
    e.preventDefault();
    if (!editingRequest) return;
    editExchangeRequest(editingRequest.id, {
      commitment: editCommitment,
      message: editMessage
    });
    setEditingRequest(null);
  };

  const handleRatingSubmit = (e) => {
    e.preventDefault();
    if (!ratingRequest) return;
    submitExchangeRating(ratingRequest.id, ratingVal);
    setRatingRequest(null);
  };

  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .tab-button {
          padding: 12px 24px;
          font-size: 0.95rem;
          font-weight: 600;
          background: transparent;
          border: none;
          color: var(--text-secondary);
          border-bottom: 2px solid transparent;
          cursor: pointer;
          transition: var(--transition-smooth);
        }
        .tab-button:hover {
          color: var(--text-primary);
        }
        .tab-button.active {
          color: var(--color-primary);
          border-bottom-color: var(--color-primary);
        }
        .proposal-card {
          padding: 24px;
          border-radius: 16px;
          margin-bottom: 24px;
        }
        .proposal-info-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 20px;
          margin: 16px 0;
          background: rgba(255, 255, 255, 0.02);
          padding: 16px;
          border-radius: 12px;
          border: 1px solid var(--border-color);
        }
        @media (max-width: 640px) {
          .proposal-info-grid {
            grid-template-columns: 1fr;
          }
        }
        .milestone-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        }
        .milestone-item:last-child {
          border-bottom: none;
        }
        .milestone-checkbox {
          cursor: pointer;
          width: 18px;
          height: 18px;
          border-radius: 4px;
          accent-color: var(--color-primary);
        }
        .modal-overlay {
          position: fixed;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justifyContent: center;
          z-index: 100;
        }
        .modal-body {
          width: 100%;
          max-width: 500px;
          margin: 16px;
          padding: 28px;
        }
      `}</style>

      {/* Header Info */}
      <div style={{ marginBottom: '35px' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#fff', marginBottom: '6px' }}>Swap Contracts Manager</h1>
        <p style={{ color: 'var(--text-secondary)' }}>Manage your active swap contracts, approve incoming offers, or log weekly commitments.</p>
      </div>

      {/* Navigation tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border-color)', gap: '16px', marginBottom: '35px', overflowX: 'auto' }}>
        <button 
          className={`tab-button ${activeTab === 'received' ? 'active' : ''}`}
          onClick={() => setActiveTab('received')}
        >
          Received Proposals ({receivedProposals.length})
        </button>
        <button 
          className={`tab-button ${activeTab === 'sent' ? 'active' : ''}`}
          onClick={() => setActiveTab('sent')}
        >
          Sent Proposals ({sentProposals.length})
        </button>
        <button 
          className={`tab-button ${activeTab === 'active' ? 'active' : ''}`}
          onClick={() => setActiveTab('active')}
        >
          Active Exchanges ({activeContracts.length})
        </button>
        <button 
          className={`tab-button ${activeTab === 'completed' ? 'active' : ''}`}
          onClick={() => setActiveTab('completed')}
        >
          Completed Swaps ({completedContracts.length})
        </button>
      </div>

      {/* Tab Streams */}
      <div>
        
        {/* ================= RECEIVED PROPOSALS STREAM ================= */}
        {activeTab === 'received' && (
          receivedProposals.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-secondary)' }}>
              <Inbox size={48} style={{ margin: '0 auto 16px auto', display: 'block', opacity: 0.5 }} />
              <h3>No incoming proposals pending</h3>
              <p style={{ fontSize: '0.9rem', marginTop: '6px' }}>Offers sent by community members will appear here.</p>
            </div>
          ) : (
            receivedProposals.map(req => {
              const sender = getMemberDetails(req.senderId);
              return (
                <div key={req.id} className="glass-panel proposal-card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '10px',
                        background: 'var(--gradient-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1rem',
                        fontWeight: '700',
                        color: '#fff',
                        border: '1px solid rgba(255, 255, 255, 0.15)',
                        flexShrink: 0
                      }}>
                        {sender.name ? sender.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>{sender.name}</h3>
                        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{sender.title}</p>
                      </div>
                    </div>
                    <span style={{ fontSize: '0.75rem', padding: '6px 12px', background: 'rgba(245, 158, 11, 0.15)', color: '#f59e0b', borderRadius: '8px', fontWeight: 'bold' }}>
                      INCOMING SWAP
                    </span>
                  </div>

                  <div className="proposal-info-grid">
                    <div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>They offer:</span>
                      <h4 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--color-secondary)', marginTop: '4px' }}>{req.skillOffered}</h4>
                    </div>
                    <div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>In exchange for your:</span>
                      <h4 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--color-primary)', marginTop: '4px' }}>{req.skillRequested}</h4>
                    </div>
                  </div>

                  <div style={{ marginBottom: '18px' }}>
                    <h5 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '6px' }}>Swap Pitch Statement:</h5>
                    <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5', background: 'rgba(0,0,0,0.2)', padding: '12px', borderRadius: '8px' }}>
                      "{req.message}"
                    </p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                      <Clock size={14} />
                      <span>Proposed Commitment: <strong>{req.commitment}</strong></span>
                    </div>
                    
                    <div style={{ display: 'flex', gap: '12px' }}>
                      <button 
                        className="btn btn-danger" 
                        onClick={() => updateRequestStatus(req.id, 'declined')}
                      >
                        <X size={16} /> Decline
                      </button>
                      <button 
                        className="btn btn-primary" 
                        onClick={() => updateRequestStatus(req.id, 'approved')}
                      >
                        <Check size={16} /> Approve & Start
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )
        )}

        {/* ================= SENT PROPOSALS STREAM ================= */}
        {activeTab === 'sent' && (
          sentProposals.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-secondary)' }}>
              <Send size={48} style={{ margin: '0 auto 16px auto', display: 'block', opacity: 0.5 }} />
              <h3>No outgoing proposals pending</h3>
              <p style={{ fontSize: '0.9rem', marginTop: '6px' }}>Go to explore page to send a skill swap proposal.</p>
            </div>
          ) : (
            sentProposals.map(req => {
              const receiver = getMemberDetails(req.receiverId);
              return (
                <div key={req.id} className="glass-panel proposal-card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '10px',
                        background: 'var(--gradient-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1rem',
                        fontWeight: '700',
                        color: '#fff',
                        border: '1px solid rgba(255, 255, 255, 0.15)',
                        flexShrink: 0
                      }}>
                        {receiver.name ? receiver.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>{receiver.name}</h3>
                        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{receiver.title}</p>
                      </div>
                    </div>
                    <span style={{ fontSize: '0.75rem', padding: '6px 12px', background: 'rgba(99, 102, 241, 0.15)', color: '#818cf8', borderRadius: '8px', fontWeight: 'bold' }}>
                      OUTGOING PROPOSAL
                    </span>
                  </div>

                  <div className="proposal-info-grid">
                    <div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>You offer to teach:</span>
                      <h4 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--color-primary)', marginTop: '4px' }}>{req.skillOffered}</h4>
                    </div>
                    <div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>You want to learn:</span>
                      <h4 style={{ fontSize: '1rem', fontWeight: '700', color: 'var(--color-secondary)', marginTop: '4px' }}>{req.skillRequested}</h4>
                    </div>
                  </div>

                  <div style={{ marginBottom: '18px' }}>
                    <h5 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '6px' }}>Your Swap Pitch Statement:</h5>
                    <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5', background: 'rgba(0,0,0,0.2)', padding: '12px', borderRadius: '8px' }}>
                      "{req.message}"
                    </p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                      <Clock size={14} />
                      <span>Commitment Proposed: <strong>{req.commitment}</strong></span>
                    </div>
                    
                    <div style={{ display: 'flex', gap: '12px' }}>
                      <button 
                        className="btn btn-secondary" 
                        onClick={() => handleEditClick(req)}
                      >
                        <Edit3 size={16} /> Edit Details
                      </button>
                      <button 
                        className="btn btn-danger" 
                        onClick={() => cancelExchangeRequest(req.id)}
                      >
                        <Trash2 size={16} /> Withdraw
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )
        )}

        {/* ================= ACTIVE CONTRACTS STREAM ================= */}
        {activeTab === 'active' && (
          activeContracts.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-secondary)' }}>
              <TrendingUp size={48} style={{ margin: '0 auto 16px auto', display: 'block', opacity: 0.5 }} />
              <h3>No active learning contracts</h3>
              <p style={{ fontSize: '0.9rem', marginTop: '6px' }}>Once proposals are approved manually, they will list active checklists here.</p>
            </div>
          ) : (
            activeContracts.map(req => {
              const partnerId = req.senderId === currentUser.id ? req.receiverId : req.senderId;
              const partner = getMemberDetails(partnerId);
              return (
                <div key={req.id} className="glass-panel proposal-card" style={{ borderLeft: '4px solid var(--color-success)' }}>
                  
                  {/* Header Row */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '20px' }}>
                    <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '10px',
                        background: 'var(--gradient-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1rem',
                        fontWeight: '700',
                        color: '#fff',
                        border: '1px solid rgba(255, 255, 255, 0.15)',
                        flexShrink: 0
                      }}>
                        {partner.name ? partner.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>Swap Contract with {partner.name}</h3>
                        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>{partner.title}</p>
                      </div>
                    </div>
                    <span style={{ fontSize: '0.75rem', padding: '6px 12px', background: 'rgba(16, 185, 129, 0.15)', color: '#34d399', borderRadius: '8px', fontWeight: 'bold' }}>
                      RUNNING EXCHANGE
                    </span>
                  </div>

                  {/* Core Swapping Skills */}
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: '20px', background: 'rgba(0,0,0,0.15)', padding: '16px', borderRadius: '12px', marginBottom: '24px' }}>
                    <div style={{ textAlign: 'center' }}>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block' }}>
                        {req.senderId === currentUser.id ? 'YOU TEACH' : 'THEY TEACH'}
                      </span>
                      <h4 style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--color-primary)', marginTop: '4px' }}>{req.skillOffered}</h4>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'block', marginTop: '4px' }}>
                        Logged: <strong>{req.hoursTaught || 0} hrs</strong>
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
                      <ArrowRight size={24} />
                    </div>

                    <div style={{ textAlign: 'center' }}>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'block' }}>
                        {req.senderId === currentUser.id ? 'YOU LEARN' : 'THEY LEARN'}
                      </span>
                      <h4 style={{ fontSize: '1.1rem', fontWeight: '700', color: 'var(--color-secondary)', marginTop: '4px' }}>{req.skillRequested}</h4>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'block', marginTop: '4px' }}>
                        Logged: <strong>{req.hoursLearned || 0} hrs</strong>
                      </span>
                    </div>
                  </div>

                  {/* Syllabus / Progress checklist */}
                  <div style={{ marginBottom: '24px' }}>
                    <h4 style={{ fontSize: '0.9rem', color: '#fff', fontWeight: '700', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <FileCheck size={16} /> Course Syllabus & Milestones
                    </h4>
                    <div style={{ background: 'rgba(0,0,0,0.2)', padding: '16px', borderRadius: '12px' }}>
                      {req.milestones && req.milestones.map(mile => (
                        <div key={mile.id} className="milestone-item">
                          <input 
                            type="checkbox" 
                            className="milestone-checkbox" 
                            checked={mile.completed}
                            onChange={() => toggleMilestone(req.id, mile.id)}
                          />
                          <span style={{ 
                            fontSize: '0.9rem', 
                            color: mile.completed ? 'var(--text-muted)' : '#f3f4f6',
                            textDecoration: mile.completed ? 'line-through' : 'none'
                          }}>
                            {mile.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                      Commitment Rate: <strong>{req.commitment}</strong>
                    </span>
                    <button 
                      className="btn btn-primary"
                      onClick={() => updateRequestStatus(req.id, 'completed')}
                    >
                      <CheckCircle size={16} /> Mark Exchange Completed
                    </button>
                  </div>

                </div>
              );
            })
          )
        )}

        {/* ================= COMPLETED SWAPS STREAM ================= */}
        {activeTab === 'completed' && (
          completedContracts.length === 0 ? (
            <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-secondary)' }}>
              <Award size={48} style={{ margin: '0 auto 16px auto', display: 'block', opacity: 0.5 }} />
              <h3>No completed exchanges yet</h3>
              <p style={{ fontSize: '0.9rem', marginTop: '6px' }}>Contracts marked finished by both sides will list history logs here.</p>
            </div>
          ) : (
            completedContracts.map(req => {
              const partnerId = req.senderId === currentUser.id ? req.receiverId : req.senderId;
              const partner = getMemberDetails(partnerId);
              return (
                <div key={req.id} className="glass-panel proposal-card" style={{ borderLeft: '4px solid var(--color-primary)' }}>
                  
                  {/* Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '18px' }}>
                    <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                      <div style={{
                        width: '48px',
                        height: '48px',
                        borderRadius: '10px',
                        background: 'var(--gradient-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1rem',
                        fontWeight: '700',
                        color: '#fff',
                        border: '1px solid rgba(255, 255, 255, 0.15)',
                        flexShrink: 0
                      }}>
                        {partner.name ? partner.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <h3 style={{ fontSize: '1.1rem', fontWeight: '700', color: '#fff' }}>Exchange Contract with {partner.name}</h3>
                        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Completed on {req.date}</p>
                      </div>
                    </div>
                    <span style={{ fontSize: '0.75rem', padding: '6px 12px', background: 'rgba(99, 102, 241, 0.15)', color: 'var(--color-primary)', borderRadius: '8px', fontWeight: 'bold' }}>
                      SWAP SUCCESS
                    </span>
                  </div>

                  {/* Hours swapped summary */}
                  <div style={{ display: 'flex', gap: '20px', background: 'rgba(0,0,0,0.12)', padding: '12px 18px', borderRadius: '10px', marginBottom: '18px' }}>
                    <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                      Teach Skill: <strong>{req.skillOffered}</strong> ({req.hoursTaught || 0} hrs)
                    </span>
                    <span style={{ color: 'var(--text-muted)' }}>|</span>
                    <span style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                      Learn Skill: <strong>{req.skillRequested}</strong> ({req.hoursLearned || 0} hrs)
                    </span>
                  </div>

                  {/* Feedback block */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                    <div>
                      {req.ratingGiven ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>You rated {partner.name}:</span>
                          <div style={{ display: 'flex', gap: '2px' }}>
                            {[1, 2, 3, 4, 5].map(star => (
                              <Star 
                                key={star} 
                                size={14} 
                                fill={star <= req.ratingGiven ? '#fbbf24' : 'none'} 
                                stroke={star <= req.ratingGiven ? '#fbbf24' : 'var(--text-muted)'} 
                              />
                            ))}
                          </div>
                        </div>
                      ) : (
                        <button 
                          className="btn btn-secondary" 
                          onClick={() => {
                            setRatingRequest(req);
                            setRatingVal(5);
                          }}
                        >
                          ⭐ Rate & Leave Feedback
                        </button>
                      )}
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
                      <Award size={14} className="text-gradient" />
                      <span>Gained +150 XP achievements!</span>
                    </div>
                  </div>

                </div>
              );
            })
          )
        )}

      </div>

      {/* ================= EDIT OUTGOING PROPOSAL MODAL ================= */}
      {editingRequest && (
        <div className="modal-overlay">
          <div className="glass-panel modal-body" style={{ background: 'rgba(15, 23, 42, 0.95)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#fff' }}>Modify Outgoing Swap Offer</h3>
              <button onClick={() => setEditingRequest(null)} style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleEditSave}>
              <div className="form-group">
                <label className="form-label">Weekly Hour Budget:</label>
                <select 
                  className="form-select"
                  value={editCommitment}
                  onChange={(e) => setEditCommitment(e.target.value)}
                  required
                >
                  <option value="1 hour per week">1 hour per week (Light exchange)</option>
                  <option value="2 hours per week">2 hours per week (Standard balance)</option>
                  <option value="3 hours per week">3 hours per week (Accelerated learn)</option>
                  <option value="5 hours per week">5 hours per week (High intensity)</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Personal Swap Statement Pitch:</label>
                <textarea 
                  className="form-input"
                  style={{ minHeight: '120px', resize: 'vertical' }}
                  value={editMessage}
                  onChange={(e) => setEditMessage(e.target.value)}
                  required
                ></textarea>
              </div>

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', borderTop: '1px solid var(--border-color)', paddingTop: '16px', marginTop: '10px' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setEditingRequest(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Offer Upgrades</button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ================= SUBMIT RATING FEEDBACK MODAL ================= */}
      {ratingRequest && (
        <div className="modal-overlay">
          <div className="glass-panel modal-body" style={{ background: 'rgba(15, 23, 42, 0.95)' }}>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', borderBottom: '1px solid var(--border-color)', paddingBottom: '12px' }}>
              <h3 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#fff' }}>Submit Feedback review</h3>
              <button onClick={() => setRatingRequest(null)} style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}>
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleRatingSubmit}>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', marginBottom: '20px', textAlign: 'center' }}>
                How was your learning experience swapping skills with {getMemberDetails(ratingRequest.senderId === currentUser.id ? ratingRequest.receiverId : ratingRequest.senderId).name}?
              </p>

              {/* Star Selector */}
              <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginBottom: '30px' }}>
                {[1, 2, 3, 4, 5].map(star => (
                  <button 
                    key={star}
                    type="button"
                    onClick={() => setRatingVal(star)}
                    style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}
                  >
                    <Star 
                      size={32} 
                      fill={star <= ratingVal ? '#fbbf24' : 'none'} 
                      stroke={star <= ratingVal ? '#fbbf24' : 'var(--text-secondary)'} 
                    />
                  </button>
                ))}
              </div>

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', borderTop: '1px solid var(--border-color)', paddingTop: '16px' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setRatingRequest(null)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Submit Review</button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};

export default Requests;
