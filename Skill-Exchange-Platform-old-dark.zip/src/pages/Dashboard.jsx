import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  TrendingUp, 
  Clock, 
  BookOpen, 
  Calendar, 
  PlusCircle, 
  Award, 
  ChevronRight,
  TrendingDown,
  Info
} from 'lucide-react';

const Dashboard = () => {
  const { sessionLogs, requests, users, logSession, currentUser } = useContext(AppContext);
  
  // Log Session Form State
  const [activeReqId, setActiveReqId] = useState('');
  const [topic, setTopic] = useState('');
  const [duration, setDuration] = useState('2');
  const [type, setType] = useState('learn');

  // Filter only active contracts for logging sessions
  const activeContracts = requests.filter(r => r.status === 'approved');

  const getPartnerName = (req) => {
    const partnerId = req.senderId === currentUser.id ? req.receiverId : req.senderId;
    const partner = users.find(u => u.id === partnerId);
    return partner ? partner.name : 'Exchange Partner';
  };

  const handleLogSubmit = (e) => {
    e.preventDefault();
    if (!activeReqId) return;
    
    logSession(activeReqId, topic, duration, type);
    
    // Reset Form
    setTopic('');
  };

  // Helper values for Stats from current user's perspective
  const userRequests = requests.filter(r => r.senderId === currentUser.id || r.receiverId === currentUser.id);
  const userRequestIds = new Set(userRequests.map(r => r.id));

  // Filter session logs involving current user's requests
  const relevantLogs = sessionLogs.filter(log => userRequestIds.has(log.requestId));

  // Map logs to current user's perspective
  const userSessionLogs = relevantLogs.map(log => {
    const isLogger = log.loggedById === currentUser.id;
    // If current user is logger, the type is exactly what they logged
    // If current user is NOT logger, the type is the opposite of what the partner logged
    let resolvedType = log.type;
    if (!isLogger) {
      resolvedType = log.type === 'teach' ? 'learn' : 'teach';
    }
    return {
      ...log,
      resolvedType
    };
  });

  const totalLearnHours = userSessionLogs
    .filter(log => log.resolvedType === 'learn')
    .reduce((sum, log) => sum + log.duration, 0);

  const totalTeachHours = userSessionLogs
    .filter(log => log.resolvedType === 'teach')
    .reduce((sum, log) => sum + log.duration, 0);

  // SVG Chart 1 (Hours Swapped Line Chart) Data mapping
  // We'll plot last 6 session logs as trend points
  const reversedLogs = [...userSessionLogs].reverse().slice(-6);
  const chartWidth = 500;
  const chartHeight = 180;
  const padding = 30;

  // Compute points
  const pointsLearn = reversedLogs
    .filter(l => l.resolvedType === 'learn')
    .map((l, i, arr) => {
      const x = padding + (i * (chartWidth - 2 * padding)) / Math.max(1, arr.length - 1);
      const y = chartHeight - padding - (l.duration * (chartHeight - 2 * padding)) / 5; // scaled max = 5 hours
      return { x, y, dur: l.duration, date: l.date };
    });

  const pointsTeach = reversedLogs
    .filter(l => l.resolvedType === 'teach')
    .map((l, i, arr) => {
      const x = padding + (i * (chartWidth - 2 * padding)) / Math.max(1, arr.length - 1);
      const y = chartHeight - padding - (l.duration * (chartHeight - 2 * padding)) / 5;
      return { x, y, dur: l.duration, date: l.date };
    });

  const makePathString = (pts) => {
    if (pts.length === 0) return '';
    return pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  };

  const makeAreaString = (pts) => {
    if (pts.length === 0) return '';
    const first = pts[0];
    const last = pts[pts.length - 1];
    const path = makePathString(pts);
    return `${path} L ${last.x} ${chartHeight - padding} L ${first.x} ${chartHeight - padding} Z`;
  };

  // SVG Chart 2 (Category Donut Chart)
  // Let's compute actual learn hours vs teach hours ratio
  const totalHours = totalLearnHours + totalTeachHours || 1;
  const learnPercentage = Math.round((totalLearnHours / totalHours) * 100);
  const teachPercentage = 100 - learnPercentage;

  // Donut values (radius = 50, circumference = 2 * pi * 50 = 314.16)
  const radius = 50;
  const circ = 2 * Math.PI * radius;
  const learnDashOffset = circ - (learnPercentage / 100) * circ;
  const teachDashOffset = circ - (teachPercentage / 100) * circ;

  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 20px;
          margin-bottom: 40px;
        }
        .dashboard-layout {
          display: grid;
          grid-template-columns: 2fr 1fr;
          gap: 30px;
        }
        @media (max-width: 1024px) {
          .dashboard-layout {
            grid-template-columns: 1fr;
          }
        }
        .widget-card {
          padding: 24px;
          border-radius: 16px;
          margin-bottom: 30px;
        }
        .log-list-container {
          max-height: 380px;
          overflow-y: auto;
        }
        .log-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 14px 16px;
          border-radius: 12px;
          background: rgba(255, 255, 255, 0.02);
          border: 1px solid var(--border-color);
          margin-bottom: 12px;
          transition: var(--transition-smooth);
        }
        .log-item:hover {
          border-color: rgba(255, 255, 255, 0.12);
          background: rgba(255, 255, 255, 0.04);
        }
      `}</style>

      {/* Page Header */}
      <div style={{ marginBottom: '35px' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#fff', marginBottom: '6px' }}>Dashboard & Progress Analytics</h1>
        <p style={{ color: 'var(--text-secondary)' }}>Track your swapped hours, log new mutual sessions, and visualize your progress tags.</p>
      </div>

      {/* Metrics Row */}
      <div className="stats-grid">
        <div className="glass-panel" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(6, 182, 212, 0.12)', color: 'var(--color-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <TrendingDown size={22} />
          </div>
          <div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>LEARNED HOURS</span>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#fff', marginTop: '2px' }}>{totalLearnHours} Hrs</h3>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(99, 102, 241, 0.12)', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <TrendingUp size={22} />
          </div>
          <div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>TEACHING HOURS</span>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#fff', marginTop: '2px' }}>{totalTeachHours} Hrs</h3>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(236, 72, 153, 0.12)', color: 'var(--color-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Clock size={22} />
          </div>
          <div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>TOTAL SWAPPED</span>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#fff', marginTop: '2px' }}>{totalLearnHours + totalTeachHours} Hrs</h3>
          </div>
        </div>

        <div className="glass-panel" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '48px', height: '48px', borderRadius: '12px', background: 'rgba(16, 185, 129, 0.12)', color: 'var(--color-success)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Award size={22} />
          </div>
          <div>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>CONTRIBUTION RANK</span>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#fff', marginTop: '2px' }}>Level {currentUser.level}</h3>
          </div>
        </div>
      </div>

      {/* Main Grid Section */}
      <div className="dashboard-layout">
        
        {/* LEFT COLUMN: CHARTS & LOG TIMELINE */}
        <div>
          
          {/* Custom SVG Charts Widget Card */}
          <div className="glass-panel widget-card" style={{ marginBottom: '30px' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff', marginBottom: '24px' }}>Hourly Swapping Progress Trend</h3>
            
            <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: '30px' }}>
              
              {/* LINE CHART GRAPH */}
              <div>
                <h4 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '14px', fontWeight: '500' }}>Recent Sessions Duration (Hours Logged)</h4>
                
                {reversedLogs.length === 0 ? (
                  <div style={{ height: '180px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', fontSize: '0.85rem', background: 'rgba(0,0,0,0.1)', borderRadius: '12px' }}>
                    <Info size={16} style={{ marginRight: '6px' }} /> Log some study sessions below to plot trends!
                  </div>
                ) : (
                  <svg width="100%" height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`} style={{ overflow: 'visible' }}>
                    <defs>
                      <linearGradient id="learnGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--color-secondary)" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="var(--color-secondary)" stopOpacity="0.0" />
                      </linearGradient>
                      <linearGradient id="teachGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="var(--color-primary)" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    {/* Grid lines */}
                    <line x1={padding} y1={padding} x2={chartWidth - padding} y2={padding} stroke="rgba(255,255,255,0.04)" />
                    <line x1={padding} y1={(chartHeight - 2*padding)/2 + padding} x2={chartWidth - padding} y2={(chartHeight - 2*padding)/2 + padding} stroke="rgba(255,255,255,0.04)" />
                    <line x1={padding} y1={chartHeight - padding} x2={chartWidth - padding} y2={chartHeight - padding} stroke="rgba(255,255,255,0.1)" />

                    {/* Shaded Areas */}
                    {pointsLearn.length > 0 && (
                      <path d={makeAreaString(pointsLearn)} fill="url(#learnGrad)" />
                    )}
                    {pointsTeach.length > 0 && (
                      <path d={makeAreaString(pointsTeach)} fill="url(#teachGrad)" />
                    )}

                    {/* Trend Paths */}
                    {pointsLearn.length > 0 && (
                      <path d={makePathString(pointsLearn)} fill="none" stroke="var(--color-secondary)" strokeWidth="3" strokeLinecap="round" />
                    )}
                    {pointsTeach.length > 0 && (
                      <path d={makePathString(pointsTeach)} fill="none" stroke="var(--color-primary)" strokeWidth="3" strokeLinecap="round" />
                    )}

                    {/* Dots / Interactive points */}
                    {pointsLearn.map((p, i) => (
                      <g key={`l-${i}`}>
                        <circle cx={p.x} cy={p.y} r="5" fill="var(--bg-deep)" stroke="var(--color-secondary)" strokeWidth="2" />
                        <text x={p.x} y={p.y - 10} fill="var(--text-secondary)" fontSize="9" textAnchor="middle">{p.dur}h</text>
                      </g>
                    ))}
                    {pointsTeach.map((p, i) => (
                      <g key={`t-${i}`}>
                        <circle cx={p.x} cy={p.y} r="5" fill="var(--bg-deep)" stroke="var(--color-primary)" strokeWidth="2" />
                        <text x={p.x} y={p.y - 10} fill="var(--text-secondary)" fontSize="9" textAnchor="middle">{p.dur}h</text>
                      </g>
                    ))}

                    {/* Y-axis labels */}
                    <text x={padding - 8} y={padding + 3} fill="var(--text-muted)" fontSize="8" textAnchor="end">5h</text>
                    <text x={padding - 8} y={(chartHeight - 2*padding)/2 + padding + 3} fill="var(--text-muted)" fontSize="8" textAnchor="end">2.5h</text>
                    <text x={padding - 8} y={chartHeight - padding + 3} fill="var(--text-muted)" fontSize="8" textAnchor="end">0h</text>
                  </svg>
                )}

                <div style={{ display: 'flex', gap: '16px', marginTop: '16px', justifyContent: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--color-secondary)' }}></span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Learning Trend</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--color-primary)' }}></span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Teaching Trend</span>
                  </div>
                </div>
              </div>

              {/* DONUT CHART */}
              <div style={{ textAlign: 'center', borderLeft: '1px solid var(--border-color)', paddingLeft: '30px' }}>
                <h4 style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '16px', fontWeight: '500' }}>Balance Distribution</h4>
                
                <svg width="100%" height="110" viewBox="0 0 120 120" style={{ transform: 'rotate(-90deg)', overflow: 'visible' }}>
                  {/* Outer circle (Teach) */}
                  <circle 
                    cx="60" 
                    cy="60" 
                    r={radius} 
                    fill="none" 
                    stroke="rgba(255,255,255,0.03)" 
                    strokeWidth="10" 
                  />
                  
                  {/* Learn Segment */}
                  <circle 
                    cx="60" 
                    cy="60" 
                    r={radius} 
                    fill="none" 
                    stroke="var(--color-secondary)" 
                    strokeWidth="10" 
                    strokeDasharray={circ}
                    strokeDashoffset={learnDashOffset}
                    strokeLinecap="round"
                  />

                  {/* Teach Segment */}
                  <circle 
                    cx="60" 
                    cy="60" 
                    r={radius} 
                    fill="none" 
                    stroke="var(--color-primary)" 
                    strokeWidth="10" 
                    strokeDasharray={circ}
                    strokeDashoffset={teachDashOffset}
                    style={{ transformOrigin: '60px 60px', transform: `rotate(${(learnPercentage/100)*360}deg)` }}
                    strokeLinecap="round"
                  />
                </svg>

                <div style={{ marginTop: '14px' }}>
                  <span style={{ fontSize: '1rem', fontWeight: 'bold', color: '#fff' }}>
                    {learnPercentage}% Learn / {teachPercentage}% Teach
                  </span>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '2px' }}>
                    Ratio score: {((totalLearnHours / (totalTeachHours || 1)).toFixed(2))}
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Session logs Timeline Widget */}
          <div className="glass-panel widget-card" style={{ marginBottom: 0 }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff', marginBottom: '20px' }}>Swap Session History Log</h3>
            
            <div className="log-list-container">
              {userSessionLogs.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', textAlign: 'center', padding: '30px 0' }}>
                  No sessions logged yet. Complete mutual hours to generate log files.
                </p>
              ) : (
                userSessionLogs.map(log => {
                  const req = requests.find(r => r.id === log.requestId) || { senderId: '', receiverId: '' };
                  const partnerId = req.senderId === currentUser.id ? req.receiverId : req.senderId;
                  const partner = users.find(u => u.id === partnerId) || { name: 'Exchange Partner' };

                  return (
                    <div key={log.id} className="log-item">
                      <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                        <div style={{ 
                          width: '38px', 
                          height: '38px', 
                          borderRadius: '10px', 
                          background: log.resolvedType === 'teach' ? 'rgba(99, 102, 241, 0.15)' : 'rgba(6, 182, 212, 0.15)', 
                          color: log.resolvedType === 'teach' ? 'var(--color-primary)' : 'var(--color-secondary)',
                          display: 'flex', 
                          alignItems: 'center', 
                          justifyContent: 'center' 
                        }}>
                          {log.resolvedType === 'teach' ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                        </div>
                        <div>
                          <h4 style={{ fontSize: '0.9rem', color: '#fff', fontWeight: '600' }}>{log.topic}</h4>
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                            With {partner.name} • {log.date}
                          </span>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span className={`badge ${log.resolvedType === 'teach' ? 'badge-tech' : 'badge-creative'}`} style={{ textTransform: 'none' }}>
                          {log.resolvedType === 'teach' ? 'Taught' : 'Learned'}
                        </span>
                        <span style={{ fontSize: '0.9rem', fontWeight: 'bold', color: '#fff' }}>
                          +{log.duration} hrs
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: LOG SESSION ACTION CARD */}
        <div>
          
          <div className="glass-panel widget-card" style={{ background: 'rgba(99, 102, 241, 0.03)', borderColors: 'rgba(99, 102, 241, 0.2)' }}>
            <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff', marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <PlusCircle size={20} className="text-gradient" /> Log Skill Exchange Hours
            </h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginBottom: '24px' }}>
              Complete mutual study hours? Log them below to update your analytics and level up!
            </p>

            {activeContracts.length === 0 ? (
              <div style={{ padding: '20px', background: 'rgba(0,0,0,0.15)', borderRadius: '12px', border: '1px solid var(--border-color)', color: 'var(--text-muted)', fontSize: '0.85rem', lineHeight: '1.5' }}>
                ⚠️ You must have at least one **Active Exchange Contract** running before you can log study hours. Approve incoming proposals under the Requests tab!
              </div>
            ) : (
              <form onSubmit={handleLogSubmit}>
                
                {/* Select Active Contract */}
                <div className="form-group">
                  <label className="form-label">Select Active Contract Partner:</label>
                  <select 
                    className="form-select"
                    value={activeReqId}
                    onChange={(e) => setActiveReqId(e.target.value)}
                    required
                  >
                    <option value="">-- Choose Contract Partner --</option>
                    {activeContracts.map(req => (
                      <option key={req.id} value={req.id}>
                        {getPartnerName(req)} (Swap: {req.skillOffered} ⇄ {req.skillRequested})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Session Type */}
                <div className="form-group">
                  <label className="form-label">Session Exchange Action Type:</label>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                    <button 
                      type="button"
                      className={`btn ${type === 'learn' ? 'btn-cyan' : 'btn-secondary'}`}
                      onClick={() => setType('learn')}
                      style={{ padding: '8px 12px', fontSize: '0.85rem' }}
                    >
                      I was Learning
                    </button>
                    <button 
                      type="button"
                      className={`btn ${type === 'teach' ? 'btn-primary' : 'btn-secondary'}`}
                      onClick={() => setType('teach')}
                      style={{ padding: '8px 12px', fontSize: '0.85rem' }}
                    >
                      I was Teaching
                    </button>
                  </div>
                </div>

                {/* Duration */}
                <div className="form-group">
                  <label className="form-label">Session Duration (Hours):</label>
                  <select 
                    className="form-select"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    required
                  >
                    <option value="0.5">30 Minutes (0.5 hrs)</option>
                    <option value="1">1 Hour (1.0 hr)</option>
                    <option value="1.5">1.5 Hours (1.5 hrs)</option>
                    <option value="2">2 Hours (2.0 hrs)</option>
                    <option value="3">3 Hours (3.0 hrs)</option>
                    <option value="4">4 Hours (4.0 hrs)</option>
                  </select>
                </div>

                {/* Topic description */}
                <div className="form-group">
                  <label className="form-label">What Topic Did You Cover?</label>
                  <input 
                    type="text" 
                    className="form-input" 
                    placeholder="e.g. Setting up ESLint, Speaking drills..."
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    required 
                  />
                </div>

                {/* Submit button */}
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '12px 16px', marginTop: '10px' }}
                >
                  Confirm & Log Session
                </button>

              </form>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};

export default Dashboard;
