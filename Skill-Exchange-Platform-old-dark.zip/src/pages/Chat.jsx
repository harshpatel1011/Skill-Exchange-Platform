import React, { useState, useContext, useRef, useEffect } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  Send, 
  MessageSquare, 
  User, 
  Star, 
  Calendar,
  Sparkles,
  Info,
  Zap,
  Clock
} from 'lucide-react';

const Chat = () => {
  const { chats, requests, users, sendMessage, currentUser } = useContext(AppContext);
  const [selectedChatId, setSelectedChatId] = useState('');
  const [inputText, setInputText] = useState('');
  
  const messagesEndRef = useRef(null);

  // Auto-scroll chat body on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chats, selectedChatId]);

  // Set default selected chat if available
  useEffect(() => {
    if (chats.length > 0 && !selectedChatId) {
      setSelectedChatId(chats[0].id);
    }
  }, [chats, selectedChatId]);

  const activeChat = chats.find(c => c.id === selectedChatId);

  const getPartnerDetails = (partnerId) => {
    return users.find(u => u.id === partnerId) || {
      name: 'External Member',
      title: 'Expert Peer',
      rating: 4.8
    };
  };

  const getRequestDetails = (reqId) => {
    return requests.find(r => r.id === reqId) || {
      skillOffered: 'Skills',
      skillRequested: 'Skills',
      status: 'active'
    };
  };

  const handleSend = (e) => {
    e.preventDefault();
    if (!inputText.trim() || !activeChat) return;

    sendMessage(activeChat.requestId, inputText.trim());
    setInputText('');
  };

  const handleQuickReply = (text) => {
    if (!activeChat) return;
    sendMessage(activeChat.requestId, text);
  };

  // Format timestamp nicely
  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const date = new Date(timeStr);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out', height: 'calc(100vh - 120px)' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .chat-layout {
          display: grid;
          grid-template-columns: 280px 1fr;
          height: 100%;
          border-radius: 16px;
          overflow: hidden;
        }
        @media (max-width: 768px) {
          .chat-layout {
            grid-template-columns: 80px 1fr;
          }
          .chat-channel-text {
            display: none;
          }
        }
        .channels-pane {
          background: rgba(17, 24, 39, 0.4);
          border-right: 1px solid var(--border-color);
          display: flex;
          flex-direction: column;
        }
        .channel-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px;
          cursor: pointer;
          border-bottom: 1px solid rgba(255, 255, 255, 0.03);
          transition: var(--transition-smooth);
        }
        .channel-item:hover {
          background: rgba(255, 255, 255, 0.03);
        }
        .channel-item.active {
          background: rgba(99, 102, 241, 0.08);
          border-left: 3px solid var(--color-primary);
        }
        .chat-pane {
          display: flex;
          flex-direction: column;
          background: rgba(10, 15, 26, 0.5);
          height: 100%;
        }
        .chat-header {
          padding: 16px 24px;
          border-bottom: 1px solid var(--border-color);
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: rgba(17, 24, 39, 0.3);
        }
        .chat-body {
          flex: 1;
          padding: 24px;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .message-bubble {
          max-width: 65%;
          padding: 12px 16px;
          border-radius: 14px;
          font-size: 0.925rem;
          line-height: 1.45;
          position: relative;
        }
        .message-bubble.incoming {
          align-self: flex-start;
          background: rgba(31, 41, 55, 0.8);
          color: var(--text-primary);
          border-bottom-left-radius: 2px;
          border: 1px solid rgba(255, 255, 255, 0.04);
        }
        .message-bubble.outgoing {
          align-self: flex-end;
          background: var(--gradient-primary);
          color: #fff;
          border-bottom-right-radius: 2px;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.25);
        }
        .typing-indicator {
          align-self: flex-start;
          background: rgba(31, 41, 55, 0.5);
          padding: 10px 16px;
          border-radius: 12px;
          font-size: 0.8rem;
          color: var(--text-muted);
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .dot-bounce {
          width: 6px;
          height: 6px;
          background: var(--text-secondary);
          border-radius: 50%;
          animation: bounce 1.2s infinite;
        }
        .dot-bounce:nth-child(2) { animation-delay: 0.2s; }
        .dot-bounce:nth-child(3) { animation-delay: 0.4s; }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
        .quick-reply-btn {
          font-size: 0.75rem;
          padding: 6px 12px;
          border-radius: 6px;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid var(--border-color);
          color: var(--text-secondary);
          cursor: pointer;
          transition: var(--transition-smooth);
        }
        .quick-reply-btn:hover {
          background: rgba(255, 255, 255, 0.08);
          color: var(--text-primary);
          border-color: rgba(255, 255, 255, 0.2);
        }
      `}</style>

      <div className="glass-panel chat-layout">
        
        {/* LEFT CHANNELS PANE */}
        <div className="channels-pane">
          <div style={{ padding: '20px', borderBottom: '1px solid var(--border-color)' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: '800', color: '#fff', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <MessageSquare size={16} className="text-gradient" /> Swapping Arenas
            </h3>
          </div>
          
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {chats.length === 0 ? (
              <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', textAlign: 'center', marginTop: '30px', padding: '10px' }}>
                No active conversations yet. Start a proposal to trigger channels!
              </p>
            ) : (
              chats.map(chat => {
                const partner = getPartnerDetails(chat.memberId);
                const req = getRequestDetails(chat.requestId);
                const lastMsg = chat.messages[chat.messages.length - 1] || { text: 'Exchange alignment drafted.' };

                return (
                  <div 
                    key={chat.id} 
                    className={`channel-item ${selectedChatId === chat.id ? 'active' : ''}`}
                    onClick={() => setSelectedChatId(chat.id)}
                  >
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '8px',
                      background: 'var(--gradient-primary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '0.85rem',
                      fontWeight: '700',
                      color: '#fff',
                      border: '1px solid rgba(255, 255, 255, 0.15)',
                      flexShrink: 0
                    }}>
                      {partner.name ? partner.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                    </div>
                    <div className="chat-channel-text" style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h4 style={{ fontSize: '0.85rem', color: '#fff', fontWeight: '700', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {partner.name}
                        </h4>
                      </div>
                      <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginTop: '2px' }}>
                        {lastMsg.senderId === currentUser?.id ? 'You: ' : ''}{lastMsg.text}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT CHAT PANE */}
        <div className="chat-pane">
          {activeChat ? (
            <>
              {/* Chat Header */}
              {(() => {
                const partner = getPartnerDetails(activeChat.memberId);
                const req = getRequestDetails(activeChat.requestId);
                return (
                  <div className="chat-header">
                    <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                      <div style={{
                        width: '42px',
                        height: '42px',
                        borderRadius: '10px',
                        background: 'var(--gradient-primary)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '0.9rem',
                        fontWeight: '700',
                        color: '#fff',
                        border: '1px solid rgba(255, 255, 255, 0.15)',
                        flexShrink: 0
                      }}>
                        {partner.name ? partner.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <h3 style={{ fontSize: '0.95rem', fontWeight: '700', color: '#fff' }}>{partner.name}</h3>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '2px' }}>
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{partner.title}</span>
                          <span style={{ width: '3px', height: '3px', borderRadius: '50%', background: 'var(--text-muted)' }}></span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
                            <Star size={10} fill="#fbbf24" stroke="#fbbf24" />
                            <span style={{ fontSize: '0.75rem', color: '#fff', fontWeight: 'bold' }}>{partner.rating}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Swap indicator */}
                    <div style={{ background: 'rgba(255,255,255,0.03)', padding: '6px 12px', borderRadius: '8px', border: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <Zap size={14} className="text-gradient" />
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                        Swap: <strong>{req.skillOffered} ⇄ {req.skillRequested}</strong>
                      </span>
                    </div>
                  </div>
                );
              })()}

              {/* Chat Messages Body */}
              <div className="chat-body">
                
                {/* Information Alignment Notice */}
                <div style={{ alignSelf: 'center', background: 'rgba(99, 102, 241, 0.05)', border: '1px dashed var(--border-hover)', borderRadius: '10px', padding: '10px 14px', display: 'flex', alignItems: 'center', gap: '8px', maxWidth: '80%', margin: '0 auto 10px auto' }}>
                  <Info size={14} style={{ color: 'var(--color-primary)' }} />
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', textAlign: 'center', lineHeight: '1.4' }}>
                    This is your direct peer-to-peer manual chat box. Messages are saved in your LocalStorage database.
                  </span>
                </div>

                {activeChat.messages.map(msg => (
                  <div 
                    key={msg.id} 
                    className={`message-bubble ${msg.senderId === currentUser?.id ? 'outgoing' : 'incoming'}`}
                  >
                    <div>{msg.text}</div>
                    <div style={{ 
                      fontSize: '0.65rem', 
                      color: msg.senderId === currentUser?.id ? 'rgba(255,255,255,0.7)' : 'var(--text-muted)', 
                      textAlign: 'right', 
                      marginTop: '4px' 
                    }}>
                      {formatTime(msg.timestamp)}
                    </div>
                  </div>
                ))}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Reply Helper Presets */}
              <div style={{ padding: '0 24px 8px 24px', display: 'flex', flexWrap: 'wrap', gap: '8px', background: 'rgba(10, 15, 26, 0.5)' }}>
                <button 
                  type="button" 
                  className="quick-reply-btn"
                  onClick={() => handleQuickReply("Hey, when are you free for our next Zoom call?")}
                >
                  🗓️ Schedule Call
                </button>
                <button 
                  type="button" 
                  className="quick-reply-btn"
                  onClick={() => handleQuickReply("I am struggling with the homework exercises. Can you help me?")}
                >
                  ❓ Help with Exercise
                </button>
                <button 
                  type="button" 
                  className="quick-reply-btn"
                  onClick={() => handleQuickReply("Awesome! That was a really helpful study session. Thanks!")}
                >
                  ⭐ Friendly Kudos
                </button>
              </div>

              {/* Chat Input Footer Form */}
              <form onSubmit={handleSend} style={{ padding: '16px 24px', background: 'rgba(17, 24, 39, 0.4)', borderTop: '1px solid var(--border-color)', display: 'flex', gap: '12px' }}>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="Type a friendly response to your swap peer..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  required
                />
                <button type="submit" className="btn btn-primary" style={{ padding: '0 22px' }}>
                  Send <Send size={16} />
                </button>
              </form>
            </>
          ) : (
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)', padding: '24px' }}>
              <MessageSquare size={48} style={{ opacity: 0.3, marginBottom: '14px' }} />
              <h3>Select a swap room channel to begin</h3>
              <p style={{ fontSize: '0.85rem', marginTop: '4px' }}>Communication will activate automatically when a contract proposal is registered!</p>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default Chat;
