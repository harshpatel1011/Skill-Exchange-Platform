import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  Search, 
  MapPin, 
  Star, 
  ArrowLeftRight, 
  BookOpen, 
  Send,
  X
} from 'lucide-react';

const Explore = () => {
  const { users, currentUser, sendExchangeRequest, requests } = useContext(AppContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [selectedMember, setSelectedMember] = useState(null); // Member chosen for sending a request
  
  // Exchange Request Modal Form State
  const [skillOffered, setSkillOffered] = useState('');
  const [skillRequested, setSkillRequested] = useState('');
  const [commitment, setCommitment] = useState('2 hours per week');
  const [message, setMessage] = useState('');

  // Derived members list: exclude current user so they don't see themselves in explore
  const members = users ? users.filter(u => u.id !== currentUser.id) : [];

  // Categories helper mapping
  const categoryKeywords = {
    All: [],
    Technology: ['React JS', 'HTML', 'CSS', 'JavaScript Basics', 'Figma (UI/UX)', 'Coding', 'Web Design'],
    Languages: ['English Speaking', 'Spanish Language', 'French'],
    Creative: ['Gourmet Cooking', 'French Baking', 'Acoustic Guitar', 'Music Theory', 'Creative Writing'],
    Business: ['Digital Marketing', 'SEO Optimization', 'Copywriting']
  };

  // Filter members based on search term and selected category tab
  const filteredMembers = members.filter(m => {
    // 1. Text Search matching
    const matchText = (
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.bio.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.skillsTeach.some(s => s.toLowerCase().includes(searchTerm.toLowerCase())) ||
      m.skillsLearn.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    // 2. Category matching
    if (activeCategory === 'All') return matchText;
    
    const keywords = categoryKeywords[activeCategory] || [];
    const matchCategory = m.skillsTeach.some(skill => 
      keywords.some(kw => skill.toLowerCase().includes(kw.toLowerCase()))
    );

    return matchText && matchCategory;
  });

  const openRequestModal = (member) => {
    setSelectedMember(member);
    // Prefill with reasonable options
    setSkillOffered(currentUser.skillsTeach[0] || '');
    setSkillRequested(member.skillsTeach[0] || '');
    setMessage(`Hey ${member.name.split(' ')[0]}, I'd love to swap my skill in ${currentUser.skillsTeach[0] || 'design/coding'} for your skill in ${member.skillsTeach[0]}! Let's connect!`);
  };

  const closeRequestModal = () => {
    setSelectedMember(null);
    setMessage('');
  };

  const handleRequestSubmit = (e) => {
    e.preventDefault();
    if (!selectedMember) return;
    
    sendExchangeRequest(selectedMember.id, {
      skillOffered,
      skillRequested,
      commitment,
      message
    });
    
    closeRequestModal();
  };

  // Check if there is an active request between current user and member
  const getRequestStatusBadge = (memberId) => {
    const activeReq = requests.find(
      r => (r.senderId === currentUser.id && r.receiverId === memberId) ||
           (r.senderId === memberId && r.receiverId === currentUser.id)
    );
    if (!activeReq) return null;
    
    let color = 'rgba(245, 158, 11, 0.2)';
    let textColor = '#fbbf24';
    if (activeReq.status === 'approved') {
      color = 'rgba(16, 185, 129, 0.2)';
      textColor = '#34d399';
    } else if (activeReq.status === 'completed') {
      color = 'rgba(99, 102, 241, 0.2)';
      textColor = '#a5b4fc';
    }
    
    return (
      <span style={{
        fontSize: '0.75rem',
        padding: '4px 8px',
        borderRadius: '6px',
        background: color,
        color: textColor,
        fontWeight: '600',
        textTransform: 'capitalize'
      }}>
        {activeReq.status} Exchange
      </span>
    );
  };

  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .search-container {
          position: relative;
          margin-bottom: 30px;
        }
        .search-icon {
          position: absolute;
          left: 18px;
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-muted);
        }
        .search-box {
          padding-left: 50px !important;
          font-size: 1.05rem !important;
        }
        .category-tab {
          padding: 8px 18px;
          border-radius: 99px;
          font-size: 0.9rem;
          font-weight: 500;
          cursor: pointer;
          background: rgba(255,255,255,0.03);
          border: 1px solid var(--border-color);
          color: var(--text-secondary);
          transition: var(--transition-smooth);
        }
        .category-tab:hover {
          background: rgba(255,255,255,0.08);
          color: var(--text-primary);
        }
        .category-tab.active {
          background: var(--gradient-primary);
          color: #fff;
          border-color: transparent;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }
        .member-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
          gap: 28px;
        }
        .member-card {
          padding: 28px;
          display: flex;
          flex-direction: column;
          height: 100%;
        }
        .member-header {
          display: flex;
          gap: 16px;
          margin-bottom: 20px;
        }
        .avatar-frame {
          position: relative;
        }
        .status-dot {
          position: absolute;
          bottom: 2px;
          right: 2px;
          width: 12px;
          height: 12px;
          background: var(--color-success);
          border: 2px solid var(--bg-deep);
          border-radius: 50%;
        }
        .skills-tag-container {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 16px;
        }
        .modal-overlay {
          position: fixed;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justifyContent: center;
          z-index: 100;
          animation: fadeInFast 0.25s ease-out;
        }
        @keyframes fadeInFast {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .modal-body {
          width: 100%;
          max-width: 580px;
          margin: 16px;
          max-height: 90vh;
          overflow-y: auto;
          animation: slideUpFast 0.25s ease-out;
        }
        @keyframes slideUpFast {
          from { transform: translateY(30px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>

      {/* Header Info */}
      <div style={{ marginBottom: '35px' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#fff', marginBottom: '6px' }}>Explore Tutors & Swap Skills</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Browse available teachers, see their ratings, and send customized exchange offers.
        </p>
      </div>

      {/* Search Input Bar */}
      <div className="search-container">
        <Search className="search-icon" size={20} />
        <input 
          type="text" 
          className="form-input search-box"
          placeholder="Search by skill name, member profile details..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Category Tabs */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginBottom: '35px' }}>
        {Object.keys(categoryKeywords).map(cat => (
          <button 
            key={cat} 
            className={`category-tab ${activeCategory === cat ? 'active' : ''}`}
            onClick={() => setActiveCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Members Cards Grid */}
      {filteredMembers.length === 0 ? (
        <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-secondary)' }}>
          <BookOpen size={48} style={{ margin: '0 auto 16px auto', display: 'block', opacity: 0.5 }} />
          <h3>No matching members found</h3>
          <p style={{ fontSize: '0.9rem', marginTop: '6px' }}>Be the first to invite colleagues or register another profile to build up the directory!</p>
        </div>
      ) : (
        <div className="member-grid">
          {filteredMembers.map(member => (
            <div key={member.id} className="glass-panel member-card">
              
              {/* Member Header Block */}
              <div className="member-header">
                <div className="avatar-frame">
                  <div style={{
                    width: '60px',
                    height: '60px',
                    borderRadius: '12px',
                    background: 'var(--gradient-primary)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '1.25rem',
                    fontWeight: '700',
                    color: '#fff',
                    border: '1px solid rgba(255, 255, 255, 0.15)',
                    boxShadow: '0 4px 12px rgba(99, 102, 241, 0.15)'
                  }}>
                    {member.name ? member.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                  </div>
                  <div className="status-dot"></div>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '8px' }}>
                    <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>{member.name}</h3>
                    {getRequestStatusBadge(member.id)}
                  </div>
                  <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', fontWeight: '500', marginTop: '2px' }}>{member.title}</p>
                  
                  {/* Rating Info */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '14px', marginTop: '6px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Star size={14} fill="#fbbf24" stroke="#fbbf24" />
                      <span style={{ fontSize: '0.85rem', color: '#f3f4f6', fontWeight: 'bold' }}>{member.rating}</span>
                    </div>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>({member.reviewsCount || 0} reviews)</span>
                  </div>
                </div>
              </div>

              {/* Bio Description */}
              <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5', marginBottom: '24px', flex: 1 }}>
                "{member.bio}"
              </p>

              {/* Teacher Skills */}
              <div style={{ marginBottom: '14px' }}>
                <h4 style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
                  Teaches:
                </h4>
                <div className="skills-tag-container">
                  {member.skillsTeach.map(skill => (
                    <span key={skill} className="badge badge-tech" style={{ textTransform: 'none' }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Learning Skills */}
              <div style={{ marginBottom: '24px' }}>
                <h4 style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '8px' }}>
                  Wants to Learn:
                </h4>
                <div className="skills-tag-container">
                  {member.skillsLearn.map(skill => (
                    <span key={skill} className="badge badge-creative" style={{ textTransform: 'none' }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Actions Footer */}
              <div style={{ display: 'flex', gap: '12px', marginTop: 'auto' }}>
                <button 
                  className="btn btn-primary"
                  style={{ flex: 1 }}
                  onClick={() => openRequestModal(member)}
                >
                  <ArrowLeftRight size={16} /> Send Swap Offer
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Exchange Contract Draft Modal Overlay */}
      {selectedMember && (
        <div className="modal-overlay">
          <div className="glass-panel modal-body" style={{ background: 'rgba(15, 23, 42, 0.95)' }}>
            
            {/* Modal Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '24px', borderBottom: '1px solid var(--border-color)' }}>
              <div>
                <h2 style={{ fontSize: '1.35rem', fontWeight: '800', color: '#fff' }}>Draft Exchange Contract</h2>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '2px' }}>
                  Initiate a learning agreement with {selectedMember.name}
                </p>
              </div>
              <button 
                onClick={closeRequestModal}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <form onSubmit={handleRequestSubmit} style={{ padding: '24px' }}>
              
              {/* Profile Card Summary */}
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center', background: 'rgba(255,255,255,0.02)', padding: '12px', borderRadius: '12px', border: '1px solid var(--border-color)', marginBottom: '24px' }}>
                <div style={{
                  width: '45px',
                  height: '45px',
                  borderRadius: '10px',
                  background: 'var(--gradient-primary)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '0.95rem',
                  fontWeight: '700',
                  color: '#fff',
                  border: '1px solid rgba(255, 255, 255, 0.15)',
                  flexShrink: 0
                }}>
                  {selectedMember.name ? selectedMember.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'U'}
                </div>
                <div>
                  <h4 style={{ color: '#fff', fontSize: '0.95rem', fontWeight: '600' }}>{selectedMember.name}</h4>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '0.8rem' }}>{selectedMember.title}</p>
                </div>
              </div>

              {/* Skills Swap Selectors */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                
                {/* Offered Skill */}
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">You Offer to Teach:</label>
                  <select 
                    className="form-select"
                    value={skillOffered}
                    onChange={(e) => setSkillOffered(e.target.value)}
                    required
                  >
                    {currentUser.skillsTeach.map(skill => (
                      <option key={skill} value={skill}>{skill}</option>
                    ))}
                  </select>
                </div>

                {/* Requested Skill */}
                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">They Offer to Teach:</label>
                  <select 
                    className="form-select"
                    value={skillRequested}
                    onChange={(e) => setSkillRequested(e.target.value)}
                    required
                  >
                    {selectedMember.skillsTeach.map(skill => (
                      <option key={skill} value={skill}>{skill}</option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Time Commitment select */}
              <div className="form-group">
                <label className="form-label">Weekly Commitment Budget:</label>
                <select 
                  className="form-select"
                  value={commitment}
                  onChange={(e) => setCommitment(e.target.value)}
                  required
                >
                  <option value="1 hour per week">1 hour per week (Light exchange)</option>
                  <option value="2 hours per week">2 hours per week (Standard balance)</option>
                  <option value="3 hours per week">3 hours per week (Accelerated learn)</option>
                  <option value="5 hours per week">5 hours per week (High intensity)</option>
                </select>
              </div>

              {/* Proposal Textarea */}
              <div className="form-group">
                <label className="form-label">Your Swap Pitch / Message:</label>
                <textarea 
                  className="form-input"
                  style={{ minHeight: '120px', resize: 'vertical' }}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={`Write a friendly proposal explaining what you hope to achieve and why this exchange is beneficial...`}
                  required
                ></textarea>
              </div>

              {/* Modal Buttons Footer */}
              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', borderTop: '1px solid var(--border-color)', paddingTop: '20px', marginTop: '10px' }}>
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={closeRequestModal}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                >
                  Send Proposal <Send size={16} />
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};

export default Explore;
