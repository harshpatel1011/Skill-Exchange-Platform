import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Compass, 
  Users, 
  RefreshCw, 
  Clock, 
  CheckCircle,
  ArrowRight,
  Code,
  BookOpen,
  Music,
  ChefHat,
  Monitor,
  PenTool
} from 'lucide-react';

const Home = () => {
  return (
    <div style={{ animation: 'fadeIn 0.5s ease-out' }}>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(15px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .hero-section {
          position: relative;
          padding: 60px 40px;
          border-radius: 24px;
          overflow: hidden;
          margin-bottom: 40px;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(236, 72, 153, 0.05) 50%, rgba(8, 11, 17, 0.9) 100%);
          border: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }
        .hero-glow {
          position: absolute;
          top: -20%;
          right: -10%;
          width: 300px;
          height: 300px;
          background: radial-gradient(circle, rgba(99,102,241,0.2) 0%, transparent 70%);
          filter: blur(40px);
          pointer-events: none;
        }
        .stat-card {
          padding: 24px;
          display: flex;
          align-items: center;
          gap: 20px;
          border-radius: 16px;
        }
        .step-card {
          padding: 30px 24px;
          border-radius: 16px;
          height: 100%;
          text-align: center;
          transition: var(--transition-smooth);
        }
        .step-card:hover {
          transform: translateY(-5px);
        }
        .popular-skill-card {
          padding: 24px;
          border-radius: 16px;
          display: flex;
          flex-direction: column;
          gap: 16px;
          height: 100%;
        }
      `}</style>

      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-glow"></div>
        <div style={{ maxWidth: '650px', position: 'relative', zIndex: 2 }}>
          <span className="badge badge-tech" style={{ marginBottom: '16px' }}>
            🔥 Zero Money, Pure Exchange
          </span>
          <h1 style={{ fontSize: '3.2rem', fontWeight: '800', lineHeight: '1.15', marginBottom: '20px', letterSpacing: '-1px' }}>
            Teach One Skill.<br/>
            Learn Another <span className="text-gradient">Free.</span>
          </h1>
          <p style={{ fontSize: '1.1rem', color: 'var(--text-secondary)', marginBottom: '30px', lineHeight: '1.6' }}>
            Welcome to the ultimate community learning exchange. Share your expertise in coding, cooking, languages, or music, and learn directly from industry peers—without spending a single dime.
          </p>
          <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
            <Link to="/explore" className="btn btn-primary" style={{ textDecoration: 'none' }}>
              Explore Skills <Compass size={18} />
            </Link>
            <Link to="/dashboard" className="btn btn-secondary" style={{ textDecoration: 'none' }}>
              View Dashboard
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Counter Row */}
      <section style={{ marginBottom: '50px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
          <div className="glass-panel stat-card">
            <div style={{ padding: '12px', borderRadius: '12px', background: 'rgba(99, 102, 241, 0.15)', color: 'var(--color-primary)' }}>
              <Users size={28} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.8rem', fontWeight: '800', color: '#fff' }}>1,428</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Community Members</p>
            </div>
          </div>

          <div className="glass-panel stat-card">
            <div style={{ padding: '12px', borderRadius: '12px', background: 'rgba(6, 182, 212, 0.15)', color: 'var(--color-secondary)' }}>
              <RefreshCw size={28} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.8rem', fontWeight: '800', color: '#fff' }}>384</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Active Exchanges</p>
            </div>
          </div>

          <div className="glass-panel stat-card">
            <div style={{ padding: '12px', borderRadius: '12px', background: 'rgba(236, 72, 153, 0.15)', color: 'var(--color-accent)' }}>
              <Clock size={28} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.8rem', fontWeight: '800', color: '#fff' }}>5,240</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Hours Swapped</p>
            </div>
          </div>

          <div className="glass-panel stat-card">
            <div style={{ padding: '12px', borderRadius: '12px', background: 'rgba(16, 185, 129, 0.15)', color: 'var(--color-success)' }}>
              <CheckCircle size={28} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.8rem', fontWeight: '800', color: '#fff' }}>98.2%</h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Exchange Success</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section style={{ marginBottom: '60px' }}>
        <h2 style={{ fontSize: '1.8rem', fontWeight: '800', marginBottom: '8px', color: '#fff' }}>
          How It Works
        </h2>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '30px' }}>
          Swap skills smoothly with our transparent, trust-based three-step pipeline.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
          <div className="glass-panel step-card">
            <div style={{ 
              width: '50px', 
              height: '50px', 
              borderRadius: '50%', 
              background: 'rgba(99, 102, 241, 0.15)', 
              color: 'var(--color-primary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.2rem',
              fontWeight: 'bold',
              margin: '0 auto 20px auto'
            }}>1</div>
            <h3 style={{ fontSize: '1.2rem', fontWeight: '700', marginBottom: '10px', color: '#fff' }}>List Your Skills</h3>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Add skills you are ready to teach and skills you want to learn to your profile.
            </p>
          </div>

          <div className="glass-panel step-card">
            <div style={{ 
              width: '50px', 
              height: '50px', 
              borderRadius: '50%', 
              background: 'rgba(6, 182, 212, 0.15)', 
              color: 'var(--color-secondary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.2rem',
              fontWeight: 'bold',
              margin: '0 auto 20px auto'
            }}>2</div>
            <h3 style={{ fontSize: '1.2rem', fontWeight: '700', marginBottom: '10px', color: '#fff' }}>Send Exchange Offers</h3>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Find matching teachers in the directory and send them a tailored mutual study proposal.
            </p>
          </div>

          <div className="glass-panel step-card">
            <div style={{ 
              width: '50px', 
              height: '50px', 
              borderRadius: '50%', 
              background: 'rgba(236, 72, 153, 0.15)', 
              color: 'var(--color-accent)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.2rem',
              fontWeight: 'bold',
              margin: '0 auto 20px auto'
            }}>3</div>
            <h3 style={{ fontSize: '1.2rem', fontWeight: '700', marginBottom: '10px', color: '#fff' }}>Log & Upgrade</h3>
            <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Chat with your partner, complete sessions, track progress milestones, and level up!
            </p>
          </div>
        </div>
      </section>

      {/* Featured Skills Grid */}
      <section style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '30px' }}>
          <div>
            <h2 style={{ fontSize: '1.8rem', fontWeight: '800', color: '#fff' }}>Popular Skills in Demand</h2>
            <p style={{ color: 'var(--text-secondary)' }}>Explore what our global community is exchanging right now.</p>
          </div>
          <Link to="/explore" className="btn btn-secondary" style={{ display: 'flex', alignItems: 'center', gap: '6px', textDecoration: 'none' }}>
            View All <ArrowRight size={16} />
          </Link>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
          
          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-tech">Technology</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>42 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(99, 102, 241, 0.12)', color: 'var(--color-primary)', display: 'flex', alignItems: 'center', justifyContainer: 'center', justifyContent: 'center' }}>
                <Code size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>React JS Development</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Build fast, interactive web applications with modern features like Hooks and Context.
            </p>
          </div>

          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-lang">Language</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>28 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(6, 182, 212, 0.12)', color: 'var(--color-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <BookOpen size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>English Conversational</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Master accent clarity, professional pitch structures, and grammar tips in real talks.
            </p>
          </div>

          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-creative">Creative</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>18 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(236, 72, 153, 0.12)', color: 'var(--color-accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <ChefHat size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>Gourmet Baking</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Understand the science behind sourdough bread, fine French pastries, and decoration.
            </p>
          </div>

          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-creative">Creative</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>15 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(245, 158, 11, 0.12)', color: 'var(--color-warning)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Music size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>Acoustic Guitar</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Learn fingerstyle techniques, guitar tabs, basic music theory, and popular chord maps.
            </p>
          </div>

          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-tech">Technology</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>19 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(6, 182, 212, 0.12)', color: 'var(--color-secondary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <PenTool size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>UI/UX Figma Design</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Create wireframes, high-fidelity prototypes, and component design libraries in Figma.
            </p>
          </div>

          <div className="glass-panel popular-skill-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span className="badge badge-other">Business</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>23 Experts</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
              <div style={{ width: '40px', height: '40px', borderRadius: '10px', background: 'rgba(16, 185, 129, 0.12)', color: 'var(--color-success)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Monitor size={20} />
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#fff' }}>SEO & Growth Ads</h3>
            </div>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: '1.5' }}>
              Learn search engine optimization, keywords research, Google Ads campaigns, and conversions tracking.
            </p>
          </div>

        </div>
      </section>
    </div>
  );
};

export default Home;
