import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { toast } from 'react-toastify';
import { 
  Zap, 
  Mail, 
  Lock, 
  User, 
  Bookmark,
  ArrowRight
} from 'lucide-react';

const Auth = () => {
  const { loginUser, signupUser, users } = useContext(AppContext);
  const [activeTab, setActiveTab] = useState('login'); // 'login' or 'signup'
  
  // Login Form State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Sign Up Form State
  const [signupName, setSignupName] = useState('');
  const [signupTitle, setSignupTitle] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupTeach, setSignupTeach] = useState('');
  const [signupLearn, setSignupLearn] = useState('');

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    if (!users || users.length === 0) {
      toast.info('💡 No registered accounts found in LocalStorage. Please select the "Create Account" tab above to register!', { theme: 'dark' });
      return;
    }
    loginUser(loginEmail, loginPassword);
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    
    // Parse skills from comma-separated inputs
    const skillsTeach = signupTeach.split(',').map(s => s.trim()).filter(Boolean);
    const skillsLearn = signupLearn.split(',').map(s => s.trim()).filter(Boolean);

    signupUser({
      name: signupName,
      title: signupTitle,
      email: signupEmail,
      password: signupPassword,
      skillsTeach: skillsTeach.length > 0 ? skillsTeach : ['Web Design'],
      skillsLearn: skillsLearn.length > 0 ? skillsLearn : ['Coding']
    });
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <style>{`
        .auth-card {
          width: 100%;
          max-width: 480px;
          padding: 40px;
          position: relative;
          z-index: 10;
        }
        .auth-tab-btn {
          flex: 1;
          padding: 12px;
          background: transparent;
          border: none;
          color: var(--text-secondary);
          font-size: 0.95rem;
          font-weight: 600;
          cursor: pointer;
          border-bottom: 2px solid transparent;
          transition: var(--transition-smooth);
        }
        .auth-tab-btn.active {
          color: var(--color-primary);
          border-bottom-color: var(--color-primary);
        }
        .auth-input-container {
          position: relative;
          margin-bottom: 18px;
        }
        .auth-input-icon {
          position: absolute;
          left: 14px;
          top: 50%;
          transform: translateY(-50%);
          color: var(--text-muted);
        }
        .auth-input {
          padding-left: 44px !important;
        }
        .glow-sphere {
          position: absolute;
          width: 400px;
          height: 400px;
          border-radius: 50%;
          filter: blur(80px);
          pointer-events: none;
          z-index: 1;
        }
      `}</style>

      {/* Futuristic Background Glowing Spheres */}
      <div className="glow-sphere" style={{
        background: 'radial-gradient(circle, rgba(99,102,241,0.15) 0%, transparent 70%)',
        top: '10%',
        left: '20%'
      }}></div>
      <div className="glow-sphere" style={{
        background: 'radial-gradient(circle, rgba(236,72,153,0.1) 0%, transparent 70%)',
        bottom: '10%',
        right: '20%'
      }}></div>

      {/* Main Glass Card Form */}
      <div className="glass-panel auth-card" style={{ background: 'rgba(15, 23, 42, 0.75)' }}>
        
        {/* Brand Logo Header */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '30px' }}>
          <div style={{
            background: 'var(--gradient-primary)',
            width: '46px',
            height: '46px',
            borderRadius: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 6px 14px rgba(99, 102, 241, 0.4)',
            marginBottom: '12px'
          }}>
            <Zap size={24} color="#fff" />
          </div>
          <h2 style={{ fontSize: '1.6rem', fontWeight: '800', letterSpacing: '-0.5px', color: '#fff' }}>
            SkillSwap
          </h2>
          <span className="text-gradient" style={{ fontSize: '0.75rem', fontWeight: '700', letterSpacing: '1px', textTransform: 'uppercase' }}>
            Exchange Learning Arena
          </span>
        </div>

        {/* Tab Toggle Switch */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--border-color)', marginBottom: '28px' }}>
          <button 
            type="button" 
            className={`auth-tab-btn ${activeTab === 'login' ? 'active' : ''}`}
            onClick={() => setActiveTab('login')}
          >
            Log In
          </button>
          <button 
            type="button" 
            className={`auth-tab-btn ${activeTab === 'signup' ? 'active' : ''}`}
            onClick={() => setActiveTab('signup')}
          >
            Create Account
          </button>
        </div>

        {/* ================= LOGIN FORM BLOCK ================= */}
        {activeTab === 'login' && (
          <form onSubmit={handleLoginSubmit}>
            <div className="auth-input-container">
              <Mail className="auth-input-icon" size={18} />
              <input 
                type="email" 
                className="form-input auth-input"
                placeholder="Account Email Address"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                required
              />
            </div>

            <div className="auth-input-container" style={{ marginBottom: '24px' }}>
              <Lock className="auth-input-icon" size={18} />
              <input 
                type="password" 
                className="form-input auth-input"
                placeholder="Account Password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px 16px', fontSize: '1rem' }}>
              Access Account <ArrowRight size={18} />
            </button>
          </form>
        )}

        {/* ================= SIGN UP FORM BLOCK ================= */}
        {activeTab === 'signup' && (
          <form onSubmit={handleSignupSubmit}>
            
            {/* Full Name */}
            <div className="auth-input-container">
              <User className="auth-input-icon" size={18} />
              <input 
                type="text" 
                className="form-input auth-input"
                placeholder="Full Name (e.g. Liam Vance)"
                value={signupName}
                onChange={(e) => setSignupName(e.target.value)}
                required
              />
            </div>

            {/* Professional Title */}
            <div className="auth-input-container">
              <Bookmark className="auth-input-icon" size={18} />
              <input 
                type="text" 
                className="form-input auth-input"
                placeholder="Professional Tag (e.g. English Lecturer)"
                value={signupTitle}
                onChange={(e) => setSignupTitle(e.target.value)}
                required
              />
            </div>

            {/* Email Address */}
            <div className="auth-input-container">
              <Mail className="auth-input-icon" size={18} />
              <input 
                type="email" 
                className="form-input auth-input"
                placeholder="Email Address"
                value={signupEmail}
                onChange={(e) => setSignupEmail(e.target.value)}
                required
              />
            </div>

            {/* Password */}
            <div className="auth-input-container" style={{ marginBottom: '20px' }}>
              <Lock className="auth-input-icon" size={18} />
              <input 
                type="password" 
                className="form-input auth-input"
                placeholder="Choose Secure Password"
                value={signupPassword}
                onChange={(e) => setSignupPassword(e.target.value)}
                required
              />
            </div>

            {/* Teach skills */}
            <div className="form-group" style={{ marginBottom: '14px' }}>
              <label className="form-label" style={{ fontSize: '0.8rem' }}>Skills I Can Teach (comma separated):</label>
              <input 
                type="text" 
                className="form-input"
                placeholder="e.g. English Speaking, Creative Writing"
                value={signupTeach}
                onChange={(e) => setSignupTeach(e.target.value)}
                required
              />
            </div>

            {/* Learn skills */}
            <div className="form-group" style={{ marginBottom: '24px' }}>
              <label className="form-label" style={{ fontSize: '0.8rem' }}>Skills I Want to Learn (comma separated):</label>
              <input 
                type="text" 
                className="form-input"
                placeholder="e.g. React JS, Figma (UI/UX)"
                value={signupLearn}
                onChange={(e) => setSignupLearn(e.target.value)}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '12px 16px', fontSize: '1rem' }}>
              Register & Begin Swapping <ArrowRight size={18} />
            </button>

          </form>
        )}

      </div>
    </div>
  );
};

export default Auth;
